<?php
include 'connect.php';

?>

<form action="upload.php" method="POST">
<input type='text' name='imagename'/>
<input type='text' name='description'/>
<input type='submit' name='submit'/>
</form>