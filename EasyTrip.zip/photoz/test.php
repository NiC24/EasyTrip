<html>
<body>
<table border=1>
<?php
//PHP CODE

for($num=0;$num<10;$num++)
{
echo '<tr><td>';  
echo $num+1;
echo '</tr></td>' ;

}
?>
</table>
<h1>Workshop</h1>
</body>
</html>